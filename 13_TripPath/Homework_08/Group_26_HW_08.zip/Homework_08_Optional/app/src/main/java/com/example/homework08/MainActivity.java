package com.example.homework08;
/*
a. Assignment #. Homework 08
b. File Name : MainActivity.java
c. Full name of the student 1: Krithika Kasaragod
d. Full name of the student 2: Sahana Srinivas
*/
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.google.android.gms.maps.model.LatLng;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements SearchLocationFragment.IListener {

    private static int AUTOCOMPLETE_REQUEST_CODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public void gotoMapFragment(ArrayList<LatLng> list, String start, String end) {
        MapFragment fragment= (MapFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentMap);
        if(fragment!=null){
            fragment.updateList(list,start,end);
        }

    }
}